import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

const Dashboard = () => {

    const [productList, setProductList] = useState([])
    const [toggleDelete, setToggleDelete] = useState(false)
    
    useEffect(() => {
        axios.get("http://localhost:8000/api/products")
            .then((res) => {
                console.log('This is dashboard Get All Products request: ', res.data.results)
                setProductList(res.data.results)
            })
            .catch((err) => {
                console.log('This is our dashboard Get All Products catch error: ', err)
            })
    }, [toggleDelete])

    const handleDelete = (e, id) => {
        console.log('This is delete function for this id: ', id)
        axios.delete(`http://localhost:8000/api/products/delete/${id}`)
        .then((res) => {
            console.log('Deletion success!')
            setToggleDelete(!toggleDelete)
        })
        .catch((err) => {
            console.log('This is handleDelete error: ', err)
        })
    }

    return (
        <div>
            <h1>Product List</h1>
            <button className='btn btn-outline-primary'><Link to={'/create'}>Add a Product</Link></button>
            <hr />
            <table className='table'>
                <thead>
                    <th>Product Title</th>
                    <th>Product Price</th>
                    <th>Product Description</th>
                    <th>Actions</th>
                </thead>
                <tbody>
                    {
                        productList.map((product, x) => {
                            return (
                                <tr key={x}>
                                    <td>{product.title}</td>
                                    <td>{product.price}</td>
                                    <td>{product.description}</td>
                                    <td>
                                        <button className='btn btn-outline-warning'><Link to={`/details/${product._id}`}>View Details</Link></button> | <button className='btn btn-outline-success'><Link to={`/update/${product._id}`}>Update</Link></button> | <button className='btn btn-outline-danger' onClick={(e) => (handleDelete(e, product._id))}>Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default Dashboard