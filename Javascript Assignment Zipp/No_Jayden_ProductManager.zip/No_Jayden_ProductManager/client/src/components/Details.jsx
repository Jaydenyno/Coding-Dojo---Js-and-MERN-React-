import React, {useEffect, useState} from 'react'
import axios from 'axios'
import {Link, useParams} from 'react-router-dom'

const Details = () => {

  const [product, setProduct] = useState([])
  const {id} = useParams()
  useEffect(() => {
    axios.get(`http://localhost:8000/api/products/${id}`)
    .then((res) => {
      console.log('One Product Details: ', res.data.results)
      setProduct(res.data.results)
    })
    .catch((err) => {
      console.log('This is Get One Product error: ', err)
    })
  }, [id])

  return (
    <div>
      <h1>Product Details</h1>
      <div className='card'>
        <div className='card-header'>
          <h3>Title:  {product.title}</h3>
        </div>
        <div className='card-body'>
          <p><span>Price:</span>  {product.price}</p>
          <p><span>Description:</span>  {product.description}</p>
        </div>
        <div className='card-footer'>
          <button className='btn btn-outline-dark'><Link to={'/'}>Return to Product List</Link></button>
        </div>
      </div>
    </div>
  )
}

export default Details