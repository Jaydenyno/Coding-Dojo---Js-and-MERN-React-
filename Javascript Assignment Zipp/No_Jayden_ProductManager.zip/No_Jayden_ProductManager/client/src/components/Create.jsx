import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate, Link } from 'react-router-dom'

const Create = () => {

  const [title, setTitle] = useState("")
  const [price, setPrice] = useState("")
  const [description, setDescription] = useState((""))

  const [errors, setErrors] = useState([])

  const navigate = useNavigate()

  const handleSubmit = (e) => {
    e.preventDefault()
    axios.post('http://localhost:8000/api/products/new', { title, price, description })
    .then((res) => {
      console.log("This is our Create Product post: ", res)
      navigate('/')
    })
    .catch(err => {
      const errorResponse = err.response.data.errors // Get the errors from err.response.data
      console.log(errorResponse)
      const errorArr = [] // Define a temp error array to push the messages in
      for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
        errorArr.push(errorResponse[key].message)
      }
      // Set errors
      setErrors(errorArr)
      navigate('/create')
    })
  }

  return (
    <div>
      <h1>Add a Product!</h1>
      <hr />
      {errors.map((err, x) => <p key={x}>{err}</p>)}
      <form className='form-group' onSubmit={handleSubmit}>
        <div>
          <label>Title: </label>
          <input type="text" className='form-control' name='title' value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div>
          <label>Price: </label>
          <input type="number" className='form-control' name='price' value={price} onChange={(e) => setPrice(e.target.value)} />
        </div>
        <div>
          <label>Description: </label>
          <input type="text" className='form-control' name='description' value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <button type='submit' className='btn btn-outline-dark'>Add Product</button> | <button className='btn btn-outline-warning'><Link to={'/'}>Cancel</Link></button>
      </form>
    </div>
  )
}

export default Create