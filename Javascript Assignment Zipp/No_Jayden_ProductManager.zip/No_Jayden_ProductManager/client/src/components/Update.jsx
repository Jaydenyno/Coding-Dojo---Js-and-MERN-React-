import React, {useState, useEffect} from 'react'
import axios from 'axios'
import { useNavigate, useParams, Link } from 'react-router-dom'

const Update = () => {

  const [title, setTitle] = useState("")
  const [price, setPrice] = useState("")
  const [description, setDescription] = useState((""))

  const {id} = useParams()
  const navigate = useNavigate()

  useEffect(() => {
    axios.get(`http://localhost:8000/api/products/${id}`)
    .then((res) => {
      console.log('This is my Get On Product to update: ', res.data.results)
      const product = res.data.results
      setTitle(product.title)
      setPrice(product.price)
      setDescription(product.description) 
    })
    .catch((err) => {
      console.log('This is update catch error: ', err)
    })
  }, [id])
  console.log(title, price, description)
  const handleSubmit = (e) => {
    e.preventDefault()
    axios.put(`http://localhost:8000/api/products/update/${id}`, {title, price, description})
    .then((res) => {
      console.log('This is our handleSubmit for update product: ', res)
      navigate('/')
    })
    .catch((err) => {
      console.log('This is update handleSubmit for update: ', err)
    })
  }

  return (
    <div>
      <h1>Update Product Details</h1>
      <hr />
      <form className='form-group' onSubmit={handleSubmit}>
        <div>
          <label>Title: </label>
          <input type="text" className='form-control' name='title' value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div>
          <label>Price: </label>
          <input type="number" className='form-control' name='price' value={price} onChange={(e) => setPrice(e.target.value)} />
        </div>
        <div>
          <label>Description: </label>
          <input type="text" className='form-control' name='description' value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <button type='submit' className='btn btn-outline-dark'>Update Product</button> | <button className='btn btn-outline-warning'><Link to={'/'}>Cancel</Link></button>
      </form>
    </div>
  )
}

export default Update