import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
import {BrowserRouter, Routes, Route} from "react-router-dom"
import { useParams } from "react-router"
import Home from "./components/Home";
import Num from "./components/Four";
import Hello from "./components/Hello";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
          <Routes>
            <Route path="/" element={<h1>Root page</h1>}></Route>
            <Route path="/home" element={<Home></Home>}></Route>
            <Route path="/:num" element={<Num></Num>}></Route>
            <Route path="/hello" element={<Hello></Hello>}></Route>
            <Route path="/hello/:color1/:color2" element={<Hello></Hello>}></Route>
          </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
