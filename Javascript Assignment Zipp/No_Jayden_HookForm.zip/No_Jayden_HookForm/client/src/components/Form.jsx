import React, { useState } from 'react';

const Form = () => {
    // State variables
    const [firstName, setFirstName] = useState("")
    const [firstNameError, setFirstNameError] = useState("")

    const [lastName, setLastName] = useState("")
    const [lastNameError, setLastNameError] = useState("")

    const [email, setEmail] = useState("")
    const [emailError, setEmailError] = useState("")

    const [password, setPassword] = useState("")
    const [passwordError, setPasswordError] = useState("")

    const [confirmPassword, setConfirmPassword] = useState("")
    const [confirmPasswordError, setConfirmPasswordError] = useState("")

    const submitHandler = (e) => {
        e.preventDefault()
        console.log("Form Submitted", firstName, lastName, email, password, confirmPassword)
        let userInfo = { firstName, lastName, email, password, confirmPassword }
        setListUserInfo([...listUserInfo, userInfo])
    }

    const handleFirstName = (e) => {
        setFirstName(e.target.value);
        if (e.target.value.length < 1) {
            setFirstNameError("First Name is required!");
        } else {
            setFirstNameError("");
        }
    }

    const handleLastName = (e) => {
        setLastName(e.target.value);
        if (e.target.value.length < 1) {
            setLastNameError("Last Name is required!");
        } else {
            setLastNameError("");
        }
    }

    const handleEmail = (e) => {
        setEmail(e.target.value);
        if (e.target.value.length < 1) {
            setEmailError("Email is required!");
        } else {
            setEmailError("");
        }
    }

    const handlePassword = (e) => {
        setPassword(e.target.value);
        if (e.target.value.length < 1) {
            setPasswordError("Password is required!");
        } else {
            setPasswordError("");
        }
    }

    const handleConfirmPassword = (e) => {
        setConfirmPassword(e.target.value);
        if (e.target.value.length != setPassword) {
            setConfirmPasswordError("Password not identical!");
        } else {
            setConfirmPasswordError("");
        }
    }


    return (
        <div>
            <form onSubmit={submitHandler}>
                <div className="form-group">
                    <label>First Name: </label>
                    {/* <input onchange={(e) => setFirstName(e.target.value)} type="text" className='form-control'/> */}
                    <input onChange={handleFirstName} type="text" className='form-control' />
                    {firstNameError ? <p>{firstNameError}</p> : ''}
                </div>
                <div className="form-group">
                    <label>Last Name: </label>
                    {/* <input onchange={(e) => setLastName(e.target.value)} type="text" className='form-control'/> */}
                    <input onChange={handleLastName} type="text" className='form-control' />
                    {lastNameError ? <p>{lastNameError}</p> : ''}
                </div>
                <div className="form-group">
                    <label>Email: </label>
                    {/* <input onchange={(e) => setEmail(e.target.value)} type="text" className='form-control'/> */}
                    <input onChange={handleEmail} type="text" className='form-control' />
                    {emailError ? <p>{emailError}</p> : ''}
                </div>
                <div className="form-group">
                    <label>Password: </label>
                    {/* <input onchange={(e) => setPassword(e.target.value)} type="text" className='form-control'/> */}
                    <input onChange={handlePassword} type="text" className='form-control' />
                    {passwordError ? <p>{passwordError}</p> : ''}
                </div>
                <div className="form-group">
                    <label>Confirm Password: </label>
                    {/* <input onchange={(e) => setConfirmPassword(e.target.value)} type="text" className='form-control'/> */}
                    <input onChange={handleConfirmPassword} type="text" className='form-control' />
                    {confirmPasswordError ? <p>{confirmPasswordError}</p> : ''}
                </div>
                {/* <button className='btn btn-outline-success mt-3'>Register</button> */}
            </form>
            <hr />
            <div>
                {
                    <div>
                        <p>First Name: {firstName}</p>
                        <p>Last Name: {lastName}</p>
                        <p>Email: {email}</p>
                        <p>Password: {password}</p>
                        <p>Confirm Password: {confirmPassword}</p>
                    </div>
                }
            </div>
        </div>
    )
}

export default Form;