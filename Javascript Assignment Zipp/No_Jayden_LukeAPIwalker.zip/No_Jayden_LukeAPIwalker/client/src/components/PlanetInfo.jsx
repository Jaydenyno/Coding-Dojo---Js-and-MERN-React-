import React, { useEffect, useState } from 'react';
import axios from 'axios'
import { useParams } from 'react-router-dom';

const PlanetInfo = () => {

    const [planet, setPlanet] = useState([])

    const {id} = useParams()

    useEffect (() => {
        axios.get(`https://swapi.dev/api/planets/${id}`)
        .then((response) => {
            console.log(response)
            console.log(response.data)
            setPlanet(response.data)
        })
        .catch((err) => {
            console.log("This is our catch all error message: ", err)
        })
    }, [id])

    return (
        <div>
            <h1>Name: {planet.name}</h1>
            <p>Climate: {planet.climate}</p>
            <p>Terrain: {planet.terrain}</p>
            <p>Surface Water: {planet.surface_water}</p>
            <p>Population: {planet.population}</p>
        </div>
    );
}

export default PlanetInfo;