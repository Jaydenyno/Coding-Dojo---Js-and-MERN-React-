import React from 'react';

const Root = () => {
    return (
        <div>
            <h1>Welcome!</h1>
        </div>
    );
}


export default Root;