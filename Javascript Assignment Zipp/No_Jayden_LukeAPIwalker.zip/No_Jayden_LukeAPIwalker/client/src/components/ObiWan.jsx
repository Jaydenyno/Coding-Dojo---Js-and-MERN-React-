import React from 'react';

const ObiWan = () => {

    return (
        <div>
            <h1>These aren't the droids you're looking for</h1>
            <p>Imaginary Picture</p>
        </div>
    );
}


export default ObiWan;