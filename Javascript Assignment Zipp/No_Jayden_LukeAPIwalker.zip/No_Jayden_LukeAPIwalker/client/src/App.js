import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
import { Routes, Route, useNavigate } from "react-router-dom"
import { useState } from "react";
import PersonInfo from "./components/PersonInfo";
import PlanetInfo from "./components/PlanetInfo";
import ObiWan from "./components/ObiWan";
import Root from "./components/Root";

function App() {

  const [type, setType] = useState("")
  const [id, setId] = useState("")

  const navigate = useNavigate()

  const sendSurvey = (e) => {
    e.preventDefault()
    console.log(type, id)
    if (type == "people") {
      if (id == 0 || id > 83) {
        navigate(`/obiwan`)
      } else {
        navigate(`/people/${id}`)
      }
    }
    if (type == "planet") {
      if (id == 0 || id > 60) {
        navigate(`/obiwan`)
      } else {
        navigate(`/planet/${id}`)
      }
    }
  }

  return (
    <div className="App">
      <div>
        <form onSubmit={sendSurvey}>
          <label style={{ marginRight: 10 }} for="type">Search for:</label>
          <select onChange={(e) => { setType(e.target.value) }} style={{ marginRight: 10 }} name="type" id="type">
            <option selected disabled hidden>Options</option>
            <option value="people">people</option>
            <option value="planet">planet</option>
          </select>
          <label style={{ marginRight: 10 }} for="number">Id:</label>
          <input onChange={(e) => {setId(e.target.value)}} style={{ marginRight: 10 }} type="number" name="number" value={id} />
          <button>Search</button>
        </form>
      </div>
      <Routes>
        <Route path="/" element={<Root></Root>}> </Route>
        <Route path="/people/:id" element={<PersonInfo></PersonInfo>}> </Route>
        <Route path="/planet/:id" element={<PlanetInfo></PlanetInfo>}> </Route>
        <Route path="/obiwan" element={<ObiWan></ObiWan>}> </Route>
      </Routes>
    </div>
  );
}

export default App;
