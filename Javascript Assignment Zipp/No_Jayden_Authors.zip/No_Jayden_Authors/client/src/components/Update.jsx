import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate, useParams, Link } from 'react-router-dom'

const Update = () => {

    const [name, setName] = useState("")

    const [errors, setErrors] = useState([])

    const { id } = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        axios.get(`http://localhost:8000/api/authors/${id}`)
        .then((res) => {
            console.log("This is our Get One Author: ", res.data.results)
            const author = res.data.results
            setName(author.name)
        })
        .catch((err) => {
            console.log("This is our Get One Author error: ", err)
        })
    }, [id])

    const handleSubmit = (e) => {
        e.preventDefault()
        axios.put(`http://localhost:8000/api/authors/update/${id}`, { name })
        .then((res) => {
            console.log("This is our handleSubmit for update author: ", res)
            navigate('/')
        })
        .catch(err => {
            const errorResponse = err.response.data.errors // Get the errors from err.response.data
            console.log(errorResponse)
            const errorArr = [] // Define a temp error array to push the messages in
            for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                errorArr.push(errorResponse[key].message)
            }
            // Set errors
            setErrors(errorArr)
            navigate(`/update/${id}`)
        })
    }

    return (
        <div>
            <h1>Update Author</h1>
            <hr />
            <form className='form-group' onSubmit={handleSubmit} >
                {errors.map((err, x) => <p key={x}>{err}</p>)}
                <div>
                    <label>Name: </label>
                    <input type="text" className='form-control' name='name' value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <button type='submit' className='btn btn-outline-dark'>Update</button> | <button className='btn btn-outline-warning'><Link to={'/'}>Back To List</Link></button>
            </form>
        </div>
    )
}

export default Update