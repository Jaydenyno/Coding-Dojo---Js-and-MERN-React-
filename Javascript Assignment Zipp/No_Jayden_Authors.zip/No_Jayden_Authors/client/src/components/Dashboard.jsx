import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'


const Dashboard = () => {

    const [authorList, setAuthorList] = useState([])
    const [toggleDelete, setToggleDelete] = useState(false)

    useEffect(() => {
        axios.get('http://localhost:8000/api/authors')
            .then((res) => {
                console.log("This is dashboard Get All Authors request: ", res.data.results)
                setAuthorList(res.data.results)
            })
            .catch((err) => {
                console.log("This is dashboard Get All Authors error: ", err)
            })
    }, [toggleDelete])

    const handleDelete = (e, id) => {
        console.log("This is delete function for this id: ", id)
        axios.delete(`http://localhost:8000/api/authors/delete/${id}`)
        .then((res) => {
            console.log("Deletion success!")
            setToggleDelete(!toggleDelete)
        })
        .catch((err) => {
            console.log("This is handleDelete error: ", err)
        })
    }

    return (
        <div>
            <h1>Author List</h1>
            <button className='btn btn-outline-primary'><Link to={'/create'}>Add Author</Link></button>
            <hr />
            <table className='table'>
                <thead>
                    <th>Name</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    {
                        authorList.map((author, x) => {
                            return (
                                <tr key={x}>
                                    <td>{author.name}</td>
                                    <td>
                                        <button className='btn btn-outline-success'><Link to={`/update/${author._id}`}>Update</Link></button> | <button className='btn btn-outline-danger' onClick={(e) => {handleDelete(e, author._id)}}>Delete</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}

export default Dashboard