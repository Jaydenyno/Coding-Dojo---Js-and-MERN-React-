import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate, Link } from 'react-router-dom'

const Create = () => {

    const [name, setName] = useState("")

    const [errors, setErrors] = useState([])

    const navigate = useNavigate()

    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://localhost:8000/api/authors/new', { name })
            .then((res) => {
                console.log("This is our create Author post: ", res)
                navigate('/')
            })
            .catch(err => {
                const errorResponse = err.response.data.errors // Get the errors from err.response.data
                console.log(errorResponse)
                const errorArr = [] // Define a temp error array to push the messages in
                for (const key of Object.keys(errorResponse)) { // Loop through all errors and get the messages
                    errorArr.push(errorResponse[key].message)
                }
                // Set errors
                setErrors(errorArr)
                navigate('/create')
            })
    }

    return (
        <div>
            <h1>Add an Author</h1>
            <hr />
            <form className='form-group' onSubmit={handleSubmit} >
                {errors.map((err, x) => <p key={x}>{err}</p>)}
                <div>
                    <label>Name: </label>
                    <input type="text" className='form-control' name='name' value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <button type='submit' className='btn btn-outline-dark'>Add</button> | <button className='btn btn-outline-warning'><Link to={'/'}>Back To List</Link></button>
            </form>
        </div>
    )
}

export default Create