import "bootstrap/dist/css/bootstrap.min.css"
import './App.css';
import { Routes, Route, Link} from 'react-router-dom'
import Dashboard from "./components/Dashboard";
import Create from "./components/Create";
import Update from "./components/Update";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Dashboard></Dashboard>}></Route>
        <Route path="/create" element={<Create></Create>}></Route>
        <Route path="/update/:id" element={<Update></Update>}></Route>
      </Routes>
    </div>
  );
}

export default App;
