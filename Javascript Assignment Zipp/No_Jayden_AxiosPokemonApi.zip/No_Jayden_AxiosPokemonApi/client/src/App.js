import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
import FetchApi from "./components/FetchApi";
import AxiosApi from "./components/AxiosApi";

function App() {
  return (
    <div className="App">
      <div>
        <FetchApi></FetchApi>
      </div>
      <div>
        <AxiosApi></AxiosApi>
      </div>
    </div>
  );
}

export default App;
