import React, {useState} from 'react';
import axios from 'axios'

const AxiosApi = () => {
    // ===== State variable =====
    const [pokemonData, setPokemonData] = useState([])

    const fetchData = () => {
        axios.get("https://pokeapi.co/api/v2/pokemon?limit=100000&offset=0")
        .then((response) => {
            // ----- Insert formatted data into state -----
            console.log(response.data.results)
            setPokemonData(response.data.results)
        })
        .catch((err) => {
            // ----- Logs any error -----
            console.log("This is our catch all error message", err)
        })
    }


    return (
        <div>
            <h1>Pokemon Axios Api Test</h1>
            <button onClick={fetchData}>Fetch</button>
            {
                pokemonData.map((pokemon, i) => {
                    return (
                        <div key={i}>
                            <p>{pokemon.name}</p>
                        </div>
                    )
                })
            }
        </div>
    );
}

export default AxiosApi;