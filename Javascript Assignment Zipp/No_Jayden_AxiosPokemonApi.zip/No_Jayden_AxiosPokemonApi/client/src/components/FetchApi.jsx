import React, { useState } from 'react';

const FetchApi = () => {
    // ===== State variable =====
    const [pokemonData, setPokemonData] = useState([])

    const fetchData = () => {
        fetch("https://pokeapi.co/api/v2/pokemon?limit=100000&offset=0")
        .then((response) => {
            // ----- Changes data into json format -----
            console.log(response)
            return response.json()
        })
        .then((response) => {
            // ----- Insert formatted data into state -----
            console.log(response.results)
            setPokemonData(response.results)
        }) 
        .catch((err) => {
            // ----- Logs any error -----
            console.log("This is our catch all fetch error", err)
        })
    }

    return (
        <div>
            <div>
                <h1>Pokemon Fetch Api Test</h1>
                <button onClick={fetchData}>Fetch</button>
            </div>
            {
                pokemonData.map((pokemon, i) => {
                    return (
                        <div key={i}>
                            <p>{pokemon.name}</p>
                        </div>
                    )
                })
            }
        </div>
    );
}

export default FetchApi;