import React, { useState } from 'react';

const ToDo = () => {
    // ===== State variables =====
    const [newToDo, setNewToDo] = useState("");
    const [toDoList, setToDoList] = useState([]);
    // ===== Validate state variables =====
    const [toDoError, setToDoError] = useState("");
    // ===== Handles submitted form =====
    const submitHandler = (e) => {
        // ----- Prevent default behavior of a page refresh
        e.preventDefault();
        console.log("Form submitted", newToDo);
        if (newToDo.length == 0) {
            return;
        }
        const toDoItem = {
            text: newToDo,
            complete: false
        }
        setToDoList([...toDoList, toDoItem]);
        setNewToDo("");
    }
    // ===== Simple validation to make sure something is inputed =====
    const validateSubmit = (e) => {
        setNewToDo(e.target.value);
        if (e.target.value.length < 1) {
            setToDoError("Please enter something!")
        } else {
            setToDoError("");
        }
    }
    /* 
    ===== Function that deletes and updates todo list within state whenever the i does not equal the index of list I want to delete 
    false will remove and true will keep =====
    */
    const handleToDoDelete = (deleteIndex) => {
        const filteredToDo = toDoList.filter((todo, i) => {
            return i !== deleteIndex;
        })
        setToDoList(filteredToDo);
    }

    const handleComplete = (index) => {
        const updatedToDo = toDoList.map((todo, i) => {
            if (index == i) {
                todo.complete = !todo.complete;
            }
            return todo;
        })
        setNewToDo(updatedToDo);
    }

    return (
        <div>
            <form onSubmit={submitHandler} className='form-group'>
                <label>Get MERN Black Belt</label>
                <input onChange={validateSubmit} type="text" className='form-control'/>
                {toDoError ? <p>{toDoError}</p> : ''}
                <button>Add</button>
            </form>
            <hr />
            <div>
                {
                    toDoList.map((list, i) => {
                        return (
                            <div key={i}>
                                <input onChange={(e) => {handleComplete(i)}} checked={list.complete} type="checkbox" name="" />
                                <p>To Do: {list.text}</p>
                                <button onClick={(e) => {handleToDoDelete(i)}}>Delete</button>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    );
}

export default ToDo;