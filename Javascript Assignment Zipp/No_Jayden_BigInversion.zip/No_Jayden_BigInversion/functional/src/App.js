import "bootstrap/dist/css/bootstrap.min.css"
import './App.css';
import PersonalCard from "./components/PersonalCard";

function App() {
  return (
    <div className="App">
      <PersonalCard name = {"Doe, Jane"} age = {45} color = {"Black"}>
        <h1>TEST TEST TEST</h1>
      </PersonalCard>
      <PersonalCard name = {"Smith, John"} age = {88} color = {"Brown"}>
        <h1>TEST TEST TEST</h1>
      </PersonalCard>
      <PersonalCard name = {"Fillmore, Millard"} age = {50} color = {"Brown"}>
        <h1>TEST TEST TEST</h1>
      </PersonalCard>
      <PersonalCard name = {"Smith, Maria"} age = {62} color = {"Brown"}>
        <h1>TEST TEST TEST</h1>
      </PersonalCard>
    </div>
  );
}

export default App;
